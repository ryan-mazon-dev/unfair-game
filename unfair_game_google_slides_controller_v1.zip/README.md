# Unfair Game Google Slides Controller

This version is built for the uploaded "THE UNFAIR GAME" template layout.

It detects:
- the board slide with tiles 1-20
- QUESTION 1 through QUESTION 20 slides
- ANSWER 1 through ANSWER 20 slides
- REVEAL ANSWER buttons
- RETURN TO HOME buttons
- point labels on answer slides

## Important

Apps Script only works after the PowerPoint is imported/opened as a Google Slides presentation.

Do not use Deploy.

## Install

1. Open the PowerPoint template in Google Slides.
2. Go to Extensions > Apps Script.
3. Replace Code.gs with the included Code.gs.
4. Add an HTML file named exactly:
   UnfairGameController
5. Paste UnfairGameController.html into that file.
6. Save.
7. Reload the Google Slides tab.
8. Use:
   Unfair Game > Open Unfair Game Controller

## Presenter workflow

1. Open the controller.
2. Enter the number of teams and team names.
3. Fill in the 20 questions, answers, and point values.
4. Click Save Setup + Update Slides.
5. Use the Play tab for a single-screen game.

## Notes

The controller is designed to avoid JSON. It uses normal form fields for the presenter.

Because Google Slides cannot run Apps Script directly from a shape click in presentation mode, the single-screen controller is the cleanest workflow for one screen.
